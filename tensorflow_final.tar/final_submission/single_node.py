import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import glob
import os
import sys
import pickle
import random
from collections import Counter
import pandas as pd
import yaml
import time


# number of neurons in each layer
config = yaml.load(open('parameters', 'r'))
INPUT_NUM = config["input_layer"]
H_LAYER = config["hidden_layer"]
OUTPUT_NUM = config["output_layer"]
ACTIVATION = config["activation"]
EPOCH = config["epochs"]
batch_size = config['batch_size']
LEARN_RATE = config['learning_rate']
# seed = config['seed']
# print(config)
# {'input_units': 1152, 'hidden_units': 500, 'output_units': 10, 'epochs': 5, 'batch_size': 128, 'learning_rate': 0.01}

# Compute data
# x = []
# y = []
# train = []
# train_x = []
# val_x = []
# test_x = []


def feature_extractor(filepath,pattern):
    """Prepare a generator which returns the feature of each video present in tfrecord."""

    file_pattern = filepath + pattern
    filenames = []
    # filenames = glob.glob(file_pattern)  # Create iterator of files present'
    localfile = glob.glob(file_pattern)  # Create iterator of files present'
    if 'data' in filepath:
        remotefiles = glob.glob('/s/chopin/a/grad/paahuni/youtube/data_train/{}'.format(pattern))
        filenames.extend(remotefiles)
    filenames.extend(localfile)
    print("Total files : {}".format(len(filenames)))
    file_count = 0
    for file in filenames:
        file_count += 1
        for example in tf.python_io.tf_record_iterator(file):
            mean_rgb = []
            mean_audio = []
            labels = []
            tf_example = tf.train.Example.FromString(example)
            # Appends the entire tfrecord
            #             tfrecord.append(tf_example)
            vid_ids = tf_example.features.feature['video_id'].bytes_list.value[0].decode(encoding='UTF-8')
            labels.extend(tf_example.features.feature['labels'].int64_list.value)
            labels_10 = list(filter(lambda x: x < 10, labels))
            if (len(labels_10) > 0):
                label_out = random.choices(labels_10, k=1).pop()
                mean_rgb.extend(tf_example.features.feature['mean_rgb'].float_list.value)
                mean_rgb.extend(tf_example.features.feature['mean_audio'].float_list.value)
                dfv = pd.DataFrame(mean_rgb)
                result = np.array([vid_ids, label_out, dfv.as_matrix().reshape(1, -1)], dtype=object)
                yield result

            else:
                continue


def generate_features(filepath,pattern):
    features = []
    file_count = 0
    for val in feature_extractor(filepath,pattern):
        file_count += 1
        features.append(val)

    return features, file_count


def format_mat(X):
    vid_list=[]
    for x in X:
        vid_list.append(x[0].tolist()[0])
    return np.array(vid_list)


def prepare_dataset(filepath,pattern):
    """ Generate the features and divide the dataset into train and validate dataset based on the percentage.
        format_max: Takes in array of 1152 feature and return list.

        array([array([[-0.38801911, -1.07207227, -0.30832627, ..., -0.09798758,
        -0.01193246,  0.71797293]])

        converted to ==>

        array([[-0.38801911, -1.07207227, -0.30832627, ..., -0.09798758,
        -0.01193246,  0.71797293],
       [ 0.03092361,  0.85047919, -0.13671038, ..., -0.80389994,
        -0.05022671, -0.00886724],

    """
    # features, count = generate_features(filepath)
    # features = np.asarray(features)
    # # percent = int(train_percent * features.shape[0])
    # np_features = features[:, 2].reshape((-1, 1))
    # np_features = format_mat(np.asarray(np_features))
    # np_labels = dense_to_one_hot(np.array(features[:, 1],dtype=int))
    # # train_x, val_x = np_features[:percent], np_features[percent:]
    # # train_y, val_y = np_labels[:percent], np_labels[percent:]
    #
    # return train_x, train_y, val_x, val_y, count
    features, count = generate_features(filepath,pattern)
    features = np.asarray(features)
    print(features.shape)
    np_features = features[:, 2].reshape((-1, 1))
    np_features = format_mat(np.asarray(np_features))
    np_labels = one_hot_converter(np.array(features[:, 1],dtype=int))

    return np_features, np_labels, count


def one_hot_converter(labels_dense, num_classes=10):
    """Convert class labels from scalars to one-hot vectors"""
    num_labels = labels_dense.shape[0]
    index_offset = np.arange(num_labels) * num_classes
    labels_one_hot = np.zeros((num_labels, num_classes))
    labels_one_hot.flat[index_offset + labels_dense.ravel()] = 1

    return labels_one_hot

def preproc(unclean_batch_x):
    """Convert values to range 0-1"""
    temp_batch = unclean_batch_x / unclean_batch_x.max()

    return temp_batch

# def batch_creator(data,labels,num):
#     """Create batch with random samples and return appropriate format"""
#     idx = np.arange(0, len(data))
#     np.random.shuffle(idx)
#     idx = idx[:num]
#     data_shuffle = data[idx]
#     labels_shuffle = labels[idx]
#
#     return np.asarray(data_shuffle), np.asarray(labels_shuffle)
def batch_creator(data,labels,num):
    # total_batch = data.shape[0]//batch_size
    """Create batch with random samples and return appropriate format"""
    idx = np.arange(0, len(data))
    np.random.shuffle(idx)
    idx = idx[:num]
    data_shuffle = data[idx]
    labels_shuffle = labels[idx]
    yield np.vstack(data_shuffle), np.vstack(labels_shuffle)
    # return np.asarray(data_shuffle), np.asarray(labels_shuffle)


with tf.name_scope('input'):
    # None -> batch size can be any size, 784 -> flattened mnist image
    x_ = tf.placeholder(tf.float32, shape=[None, INPUT_NUM], name="x-input")
    # target 10 output classes
    y_ = tf.placeholder(tf.float32, shape=[None, OUTPUT_NUM], name="y-input")


tf.set_random_seed(1)
# Testing Code
opt = INPUT_NUM
mul = x_
for i, layer in enumerate(H_LAYER):
    with tf.name_scope(name="Layer-{}".format(i)):
        w = tf.Variable(tf.truncated_normal([opt, layer]), name="W{}".format(i))
        b = tf.Variable(tf.truncated_normal([layer]), name="B{}".format(i))
        h = eval(ACTIVATION[i])(tf.add(tf.matmul(mul, w), b))
        opt = layer
        mul = h

with tf.name_scope(name="Output"):
    w3 = tf.Variable(tf.truncated_normal([opt, OUTPUT_NUM], stddev=0.01), name="W_out")
    b3 = tf.Variable(tf.truncated_normal([OUTPUT_NUM]), name="B_out")
    y_predict = tf.nn.softmax(tf.add(tf.matmul(mul, w3), b3))

# recall = tf.metrics.recall(labels=y_, predictions=y_predict)
# precision = tf.metrics.precision(labels=y_, predictions=y_predict)

with tf.name_scope(name="Entropy/Cost"):
    cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=y_predict, labels=y_), name="X-Entropy")

    # reg = tf.nn.l2_loss(w1)+tf.nn.l2_loss(w2)+tf.nn.l2_loss(w3)
    # loss = tf.reduce_mean(cost+reg*0.01)

with tf.name_scope("train"):
    optimizer = tf.train.AdamOptimizer(learning_rate=LEARN_RATE).minimize(cost)

with tf.name_scope("accuracy"):
    correct_prediction = tf.equal(tf.argmax(y_predict, 1), tf.argmax(y_, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

tf.summary.scalar('accuracy', accuracy)
tf.summary.scalar('cost', cost)
init = tf.global_variables_initializer()
all_summ = tf.summary.merge_all()
saver = tf.train.Saver()
train_x, train_y, data_cnt = prepare_dataset('data/', "*[A-E].tfrecord")
val_x, val_y, val_cnt = prepare_dataset('validate/', "*[0-9].tfrecord")
print("Train count: {} Validation count={}".format(data_cnt, val_cnt))

with tf.Session() as sess:
    # create initialized variables
    sess.run(init)
    writer = tf.summary.FileWriter('logs/{}-{}-{}/'.format(H_LAYER,LEARN_RATE,time.strftime("%H:%M:%S")))
    writer.add_graph(sess.graph)

    # ## Code before recall,precision modification....
    # for epoch in range(epochs):
    #     # avg_cost = 0
    #     total_batch = int(data_cnt / batch_size)
    #     for i in range(total_batch):
    #
    #         batch_x, batch_y = batch_creator(batch_size, train_x, train_y)
    #         _, acc,c,summ = sess.run([optimizer, accuracy,cost,all_summ], feed_dict={x_: batch_x, y_: batch_y})
    #         # avg_cost += c / total_batch
    #         print("Epoch:", (epoch + 1), "accuracy:{:.5f}  cost ={:.5f}".format(acc, c))
    #         writer.add_summary(summ, epoch)
    #         if i % 50 == 0 or epoch == max(range(epochs)) or i == total_batch:
    #             pred_temp = tf.equal(tf.argmax(y_predict, 1), tf.argmax(y_, 1))
    #             accuracy = tf.reduce_mean(tf.cast(pred_temp, "float"))
    #             print("Validation Accuracy:", accuracy.eval({x_: val_x.reshape(-1, INPUT_NUM), y_: val_y}))
    #     #     saver.save(sess, os.path.join("model", "model.ckpt"), epoch)
    #     # print("Epoch:", (epoch + 1), "accuracy:{:.5f}  cost ={:.5f}".format(acc, avg_cost))
    #
    # print("\nTraining complete!")
    #
    # # find predictions on val set
    # pred_temp = tf.equal(tf.argmax(y_predict, 1), tf.argmax(y_, 1))
    # accuracy = tf.reduce_mean(tf.cast(pred_temp, "float"))
    # print("Validation Accuracy:", accuracy.eval({x_: val_x.reshape(-1, INPUT_NUM), y_: val_y}))
    #
    #
    # # Evaluate test accuracy on test dataset.
    #
    # # predict = tf.argmax(output_layer, 1)
    # # pred = predict.eval({x: test_x.reshape(-1, input_units)})

    # batch_size = 200
    time_iter = []
    start_time = time.time()
    end_time = 0
    iteration=[]
    time_s=[]
    for i in range(EPOCH):
        bg = batch_creator(train_x, train_y,batch_size)
        for j, (data_batch, label_batch) in enumerate(bg):
            _, loss_, acc = sess.run([optimizer, cost, accuracy],feed_dict={x_: data_batch,y_: label_batch})
            # step += 1
            print("Loss:{:.5f} Accuracy:{:.5f}".format(loss_, acc))
            sys.stdout.flush()
            #if j % 20 == 0 or i == max(range(EPOCH)):
        end_time = time.time()
        _,vacc,vloss,summ = sess.run([optimizer,accuracy,cost,all_summ],feed_dict={x_:val_x,y_:val_y})
        iteration.append(vloss)
        writer.add_summary(summ, end_time-start_time)
        print("Validation Accuracy: {:.5f} Loss: {:.5f}".format(vacc,vloss))

        time_iter.append((i,(end_time-start_time)))
        time_s.append((end_time-start_time))
    print("Iteration time: \n",time_s)
    print("Iteration time: \n",iteration)
    print("Start time:{} \nEnd time:{}".format(time.gmtime(start_time),time.gmtime(end_time)))

plt.plot(iteration,time_s,'or-')
plt.title("Time taken for iteration")
plt.xlabel("Iteration")
plt.ylabel("Time(ms)")
plt.savefig("Time-Iteration.png")
