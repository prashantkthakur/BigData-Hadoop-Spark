'''https://github.com/deepsense-ai/tensorflow_on_slurm/blob/master/examples/cifar-10/main.py'''
import tensorflow as tf
import numpy as np
import pandas as pd
import yaml
import glob
import random
import sys
import time

config = yaml.load(open('dist_param', 'r'))
INPUT_NUM = config["model"]["input"]
OUTPUT_NUM = config["model"]["output"]
H_LAYER = config["model"]["hidden_layer"]
ACTIVATION = config["model"]["activation"]
LEARN_RATE = config["model"]["learning_rate"]
LOGDIR = config["log_dir"]
MODEL_DIR = config["model_dir"]
EPOCH = config["model"]["epochs"]
BATCH_SIZE = config["model"]["batch_size"]
DEVICE = config["model"]["device"]
PARAM_SERVER = config["model"]["parameter_server"]
WORKERS = config["model"]["workers"]
PRINT_EVERY = config["model"]["print_every"]
FILE_PATTERN = config["file_pattern"]
V_FILE_PATTERN = config["v_file_pattern"]
DATA_DIR = config["data_dir"]
VAL_DIR = config["validate_dir"]


def feature_extractor(filepath,pattern):
    """Prepare a generator which returns the feature of each video present in tfrecord."""

    file_pattern = filepath + pattern
    filenames = []
    # filenames = glob.glob(file_pattern)  # Create iterator of files present'
    localfile = glob.glob(file_pattern)  # Create iterator of files present'
    if 'data' in filepath:
        remotefiles = glob.glob('/s/chopin/a/grad/paahuni/youtube/data_train/{}'.format(pattern))
        filenames.extend(remotefiles)
    filenames.extend(localfile)
    print("Total files : {}".format(len(filenames)))
    file_count = 0
    try:
        for file in filenames:
            file_count += 1
            for example in tf.python_io.tf_record_iterator(file):
                mean_rgb = []
                mean_audio = []
                labels = []
                tf_example = tf.train.Example.FromString(example)
                # Appends the entire tfrecord
                #             tfrecord.append(tf_example)
                vid_ids = tf_example.features.feature['video_id'].bytes_list.value[0].decode(encoding='UTF-8')
                labels.extend(tf_example.features.feature['labels'].int64_list.value)
                labels_10 = list(filter(lambda x: x < 10, labels))
                if (len(labels_10) > 0):
                    label_out = random.choices(labels_10, k=1).pop()
                    mean_rgb.extend(tf_example.features.feature['mean_rgb'].float_list.value)
                    mean_rgb.extend(tf_example.features.feature['mean_audio'].float_list.value)
                    dfv = pd.DataFrame(mean_rgb)
                    result = np.array([vid_ids, label_out, dfv.as_matrix().reshape(1, -1)], dtype=object)
                    yield result

                else:
                    continue
    except:
        pass


def generate_features(filepath,pattern):
    features = []
    file_count = 0
    for val in feature_extractor(filepath,pattern):
        file_count += 1
        features.append(val)

    return features, file_count


def format_mat(X):
    vid_list=[]
    for x in X:
        vid_list.append(x[0].tolist()[0])
    return np.array(vid_list)


def prepare_dataset(filepath,pattern):
    """ Generate the features and divide the dataset into train and validate dataset based on the percentage.
        format_max: Takes in array of 1152 feature and return list.

        array([array([[-0.38801911, -1.07207227, -0.30832627, ..., -0.09798758,
        -0.01193246,  0.71797293]])

        converted to ==>

        array([[-0.38801911, -1.07207227, -0.30832627, ..., -0.09798758,
        -0.01193246,  0.71797293],
       [ 0.03092361,  0.85047919, -0.13671038, ..., -0.80389994,
        -0.05022671, -0.00886724],

    """
    # features, count = generate_features(filepath)
    # features = np.asarray(features)
    # # percent = int(train_percent * features.shape[0])
    # np_features = features[:, 2].reshape((-1, 1))
    # np_features = format_mat(np.asarray(np_features))
    # np_labels = dense_to_one_hot(np.array(features[:, 1],dtype=int))
    # # train_x, val_x = np_features[:percent], np_features[percent:]
    # # train_y, val_y = np_labels[:percent], np_labels[percent:]
    #
    # return train_x, train_y, val_x, val_y, count
    features, count = generate_features(filepath,pattern)
    features = np.asarray(features)
    print(features.shape)
    np_features = features[:, 2].reshape((-1, 1))
    np_features = format_mat(np.asarray(np_features))
    np_labels = one_hot_converter(np.array(features[:, 1],dtype=int))

    return np_features, np_labels, count


def one_hot_converter(labels_dense, num_classes=10):
    """Convert class labels from scalars to one-hot vectors"""
    num_labels = labels_dense.shape[0]
    index_offset = np.arange(num_labels) * num_classes
    labels_one_hot = np.zeros((num_labels, num_classes))
    labels_one_hot.flat[index_offset + labels_dense.ravel()] = 1

    return labels_one_hot


def preproc(unclean_batch_x):
    """Convert values to range 0-1"""
    temp_batch = unclean_batch_x / unclean_batch_x.max()

    return temp_batch


def batch_creator(data,labels,num):
    # total_batch = data.shape[0]//batch_size
    """Create batch with random samples and return appropriate format"""
    idx = np.arange(0, len(data))
    np.random.shuffle(idx)
    idx = idx[:num]
    data_shuffle = data[idx]
    labels_shuffle = labels[idx]
    yield np.vstack(data_shuffle), np.vstack(labels_shuffle)
    # return np.asarray(data_shuffle), np.asarray(labels_shuffle)

# Define Cluster
cluster = tf.train.ClusterSpec({"ps": PARAM_SERVER, "worker": WORKERS})
# input flags
tf.app.flags.DEFINE_string("job_name", "", "Either 'ps' or 'worker'")
tf.app.flags.DEFINE_integer("task_index", 0, "Index of task within the job")
FLAGS = tf.app.flags.FLAGS
server = tf.train.Server(cluster,job_name=FLAGS.job_name,task_index=FLAGS.task_index)
if FLAGS.job_name == 'ps':

    server.join()
    sys.exit(0)


tf.set_random_seed(1)



def bias_variable(shape):
    with tf.device("/job:ps/task:0"):
        initial = tf.constant(0.1, shape=shape)
        v = tf.Variable(initial)
    return v

with tf.device("/job:ps/task:0"):
    with tf.name_scope('input'):
        x_ = tf.placeholder(tf.float32, shape=[None, INPUT_NUM], name="x-input")
        # target 10 output classes
        y_ = tf.placeholder(tf.uint8, shape=[None, OUTPUT_NUM], name="y-input")
    with tf.name_scope(name="Layer-1"):
        w = tf.Variable(tf.truncated_normal([INPUT_NUM, 500]), name="W")
        b = tf.Variable(tf.truncated_normal([500]), name="B1")
    with tf.name_scope(name="Output"):
        w3 = tf.Variable(tf.truncated_normal([500, OUTPUT_NUM]), name="W_out")
        b3 = tf.Variable(tf.truncated_normal([OUTPUT_NUM]), name="B_out")

    global_step = tf.get_variable('global_step', [], initializer=tf.constant_initializer(0), dtype=tf.int32)


is_chief = FLAGS.task_index == 0
# opt = INPUT_NUM
# mul = x_
# for i, layer in enumerate(H_LAYER):
#     with tf.name_scope(name="Layer-{}".format(i)):
#         w = tf.Variable(tf.truncated_normal([opt, layer]), name="W{}".format(i))
#         b = tf.Variable(tf.truncated_normal([layer]), name="B{}".format(i))
#         h = eval(ACTIVATION[i])(tf.add(tf.matmul(mul, w), b))
#         opt = layer
#         mul = h
#
# with tf.name_scope(name="Output"):
#     w3 = tf.Variable(tf.truncated_normal([opt, OUTPUT_NUM], stddev=0.01), name="W_out")
#     b3 = tf.Variable(tf.truncated_normal([OUTPUT_NUM]), name="B_out")
#     y_predict = tf.nn.softmax(tf.add(tf.matmul(mul, w3), b3))

# global_step = tf.get_variable('global_step', [],initializer=tf.constant_initializer(0),dtype=tf.int32)
# for i in range(len(WORKERS)):
#     with tf.device(tf.train.replica_device_setter(worker_device="/job:worker/task:%d" % i,cluster=cluster)):
with tf.device('/job:worker/task:{}'.format(FLAGS.task_index)):
    h = tf.nn.relu(tf.add(tf.matmul(x_, w), b))
    y_predict = tf.nn.softmax(tf.add(tf.matmul(h, w3), b3))
    recall = tf.metrics.recall(labels=y_, predictions=y_predict)
    precision = tf.metrics.precision(labels=y_, predictions=y_predict)
    with tf.name_scope(name="Entropy/Cost"):
        cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=y_predict, labels=y_), name="X-Entropy")

        # global_step = tf.get_variable('global_step', [],initializer=tf.constant_initializer(0),trainable=False)
        # global_step = bias_variable([])

    with tf.name_scope("train"):
        # optimizer = tf.train.AdamOptimizer(learning_rate=LEARN_RATE).minimize(cost, global_step=global_step)
        optimizer = tf.train.AdamOptimizer(learning_rate=LEARN_RATE).minimize(cost, global_step=global_step)
        # syn_opt = tf.train.SyncReplicasOptimizer(optimizer, replicas_to_aggregate=len(WORKERS),total_num_replicas=len(WORKERS))
        # train_step = syn_opt.minimize(cost, global_step=global_step)

        # sync_replicas_hook = syn_opt.make_session_run_hook(is_chief)

    with tf.name_scope("accuracy"):
        correct_prediction = tf.equal(tf.argmax(y_predict, 1), tf.argmax(y_, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

# tf.summary.scalar("recall",recall[0])
tf.summary.scalar('accuracy', accuracy)
tf.summary.scalar('cost', cost)
init = tf.global_variables_initializer()
all_summ = tf.summary.merge_all()
# summary_hook = tf.train.SummarySaverHook(save_secs=1,output_dir=LOGDIR + "/{}-{}-{}/".format(LEARN_RATE,H_LAYER,time.strftime("%H:%M:%S")),summary_op=all_summ)
config = tf.ConfigProto(intra_op_parallelism_threads=10,inter_op_parallelism_threads=5)
# SUMMARY_DIR = LOGDIR + "/{}-{}-{}/".format(LEARN_RATE,H_LAYER,time.strftime("%H:%M:%S"))
sess = tf.train.MonitoredTrainingSession(config=config,master=server.target,is_chief=is_chief)
# sess = tf.train.MonitoredTrainingSession(master=server.target,is_chief=is_chief,save_summaries_steps=10,hooks=[summary_hook])
writer = tf.summary.FileWriter(LOGDIR + "/{}-{}-{}-{}/".format(LEARN_RATE,H_LAYER,EPOCH,FLAGS.task_index), graph=tf.get_default_graph())
# from tensorflow.python.training.summary_io import SummaryWriterCache
# writer = SummaryWriterCache.get(SUMMARY_DIR)

def batch_generator(data, labels, batch_size=32):
    x_batch, y_batch = [], []
    for d, l in zip(data, labels):
        x_batch.append(d)
        y_batch.append(l)
        if len(x_batch) == batch_size:
            yield np.vstack(x_batch),np.vstack(y_batch)
            x_batch = []
            y_batch = []






# Load data
train_x, train_y, data_cnt = prepare_dataset('data/', FILE_PATTERN)
total_chunk = data_cnt // BATCH_SIZE
# global_chunks.assign([train_x,train_y])
val_x, val_y, val_cnt = prepare_dataset('validate/', V_FILE_PATTERN)
print("Train count: {} Validation count={}".format(data_cnt, val_cnt))
def batcher(data,label,batch_size,chunk):
    # chunk = global_step % total_chunk
    print("Batching: step={}  total chunk={} proc_chunk={}".format(step,total_chunk,chunk))
    if chunk == total_chunk-1:
        data_batch = data[chunk*batch_size:,:]
        label_batch = label[chunk*batch_size:,:]
    else:
        data_batch = data[chunk*batch_size:(chunk+1)*batch_size,:]
        label_batch = label[chunk*batch_size:(chunk+1)*batch_size,:]
    return np.vstack(data_batch), np.vstack(label_batch)

step = 0
time_iter = []
start_time = time.time()
end_time = 0
losses=[]

# fp = open("time_iter{}".format(FLAGS.task_index), "a")
# fp = open("time_loss{}".format(FLAGS.task_index), "a")
for i in range(EPOCH):
    # bg = batcher(train_x, train_y,BATCH_SIZE,chunk)
    # for j, (data_batch, label_batch) in enumerate(bg):
    # global_chunks = list(range(total_chunk))
    for _ in range(total_chunk//len(WORKERS)):
        chunk = step % total_chunk
        # print("Accessing chunk: %d"%chunk)
        data_batch, label_batch = batcher(train_x,train_y,BATCH_SIZE,chunk)
        # if (j+i) % len(WORKERS) != FLAGS.task_index:
        #     continue
        _, loss_, acc, step, recl, prec = sess.run([optimizer, cost, accuracy, global_step,recall,precision],feed_dict={x_: data_batch,y_: label_batch})
        # step += 1
        print("Iter: {} Chunk:{} TaskIdx:{} Loss:{:.5f} Accuracy:{:.5f} GlobalStep:{} Recall:{} Precision:{}".format(i,chunk, FLAGS.task_index, loss_, acc, step,recl[0],prec[0]))
        sys.stdout.flush()
        # print("Chunk:%s"%chunks)
        # try:
        #     global_chunks.remove(chunk)
        #     print("Removing chunk :%s"%chunk)
        # except ValueError:
        #     pass

    # if i % 2 == 0 or i == max(range(EPOCH)):
    _,vacc,vloss,summ,rcl,pre = sess.run([optimizer,accuracy,cost,all_summ,recall,precision],feed_dict={x_:val_x,y_:val_y})
    writer.add_summary(summ,i)
    print("Validation Accuracy: {:.5f} Loss: {:.5f}, Recall:{} Precision:{}".format(vacc,vloss,rcl[0],pre[0]))
    end_time = time.time()
    # fp.write("{},{}\n".format(i, (end_time - start_time) * 1000))
    # fp.write("{},{}\n".format(vloss,time_taken))
    # time_iter.append((i,(end_time-start_time)*1000))
# print("Iteration time: \n",time_iter)
# print("Start time:{} \nEnd time:{}".format(time.gmtime(start_time),time.gmtime(end_time)))
# fp.close()
final_time = time.time()
print("Total time taken for {} is {}".format(EPOCH,final_time-start_time))
# with open("final_time.csv","a") as fp:
#     fp.write("{},{},{},{}\n".format(H_LAYER,EPOCH,len(WORKERS),final_time-start_time))
